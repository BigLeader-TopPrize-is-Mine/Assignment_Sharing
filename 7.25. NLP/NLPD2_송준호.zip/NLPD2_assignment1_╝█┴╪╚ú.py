import re
import requests
from bs4 import BeautifulSoup as bs
url = "https://edition.cnn.com/2023/07/24/football/new-zealand-switzerland-norway-womens-world-cup-2023-spt-intl/index.html"

response = requests.get(url)
r1 = response.content

soup = bs(r1, 'html.parser')
article_origin = soup.find('div',class_='article__content').get_text()

scores = re.findall("[0-9]-[0-9]",article_origin)
worldcup = re.findall("World Cup",article_origin)

print(len(scores))
print(len(worldcup))