using UiPath.CodedWorkflows;

namespace D2L3_DataTable생성방법
{
    public class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{};
        }
    }
}