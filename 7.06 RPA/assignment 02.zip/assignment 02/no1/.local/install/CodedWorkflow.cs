using UiPath.CodedWorkflows;

namespace D2L1_워크플로호출과인수이해
{
    public class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{};
        }
    }
}