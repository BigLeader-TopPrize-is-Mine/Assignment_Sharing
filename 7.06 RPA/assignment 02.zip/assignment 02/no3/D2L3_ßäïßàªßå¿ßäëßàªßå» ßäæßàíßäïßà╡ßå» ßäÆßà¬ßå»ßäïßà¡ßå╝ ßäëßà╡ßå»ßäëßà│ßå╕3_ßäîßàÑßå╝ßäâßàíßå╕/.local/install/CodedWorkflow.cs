using UiPath.CodedWorkflows;

namespace D2L3_엑셀파일활용실습3_정답
{
    public class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{};
        }
    }
}